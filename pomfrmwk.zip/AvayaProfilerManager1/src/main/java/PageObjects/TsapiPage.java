package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class TsapiPage {
	
	WebDriver driver;
	
	
	public TsapiPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//span[normalize-space()='System Management']")
	private WebElement System_management;

	public void  ClickOnSystem_management() {
		try {
			System_management.click();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw new AssertionError("System_management not clicked", e);
		}
	}
	
	@FindBy(xpath = "//a[normalize-space()='TSAPI Details']")
	private WebElement Tsapi_details;
	public void  ClickOnTsapi_details() {
		try {
			Tsapi_details.click();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw new AssertionError("Tsapi_details not clicked", e);
		}
	}
	
	
	@FindBy(xpath = "//input[@name='createTSAPI']")
	private WebElement Add_Tsapi_btn;
	public void  ClickOnAdd_Tsapi_btn() {
		try {
			Add_Tsapi_btn.click();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw new AssertionError("Add_Tsapi_btn not clicked", e);
		}
	}
	
	@FindBy(xpath = "//input[@placeholder='TSAPI Name ....']")
	private WebElement Tsapi_name;

	public void setTsapi_name(String strTsapiName) {
		try {
			Tsapi_name.sendKeys(strTsapiName);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw new AssertionError("Tsapi Name not entered", e);
		}
	}
	
	@FindBy(xpath = "//select[@ng-model=\"aesDetail\"]")
	private WebElement AES_Station_link;
	public void getAES_Station_link(String string){
		 try {
	            Select dropdown = new Select(AES_Station_link);
	            dropdown.selectByVisibleText(string);
	        } catch (Exception e) {
	        	System.out.println(e.getMessage());
				throw new AssertionError(" AES_Station_link not selected", e);
	        }
	}

	@FindBy(xpath = "//input[@id='priorityImp']")
	private WebElement Priority;

	public void setPriority(String strPriority) {
		try {
			Priority.sendKeys(strPriority);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw new AssertionError("Priority not entered", e);
		}	
	}
	
	@FindBy(xpath = "//input[@name='add']")
	private WebElement Add_btn_AES;

	public void ClickOnAdd_btn_AES() {
		try {
			Add_btn_AES.click();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw new AssertionError("Add_btn_AES not clicked", e);
		}	
	}
	
	@FindBy(xpath = "//input[@name='save']")
	private WebElement Save_btn_AES;

	public void ClickOnSave_btn_AES() {
		try {
			Save_btn_AES.click();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw new AssertionError("Save_btn_AES not clicked", e);
		}	
	}
}
