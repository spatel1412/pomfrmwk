package TestCasesExecution;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import BaseClass.BrowserSetup;
import ExcelReader.getExcelData;
import PageObjects.LoginPage;
import PageObjects.TsapiPage;
import Utilities.utility;
import atu.testrecorder.ATUTestRecorder;

public class TsapiPageFunctionality extends getExcelData {
	static WebDriver driver;
	LoginPage loginpage;
	TsapiPage tsapipage;
	ATUTestRecorder recorder;
	utility util;
	static Logger log = Logger.getLogger(TsapiPageFunctionality.class.getName());
	ExtentReports extent;
	ExtentTest logger;
	
//	public static String SheetName = "Tsapi";
//    public static String FilePath = System.getProperty("user.dir") + "\\data\\Parameters.xlsx";
//    public static Object[][] ExcelData;

	static Properties prop;
	static FileInputStream fileInput;
	
	static File file = new File(System.getProperty("user.dir") + "\\config\\userloginadmin.properties");


//
//    @DataProvider(name = "getCommonData")
//    public static Object[][] getCommonData() throws Exception{
//
//        Sheet = DataSheet(FilePath, SheetName);
//        int rowCount = Sheet.getLastRowNum();
//        int colCount = Sheet.getRow(0).getLastCellNum();
//    
//        ExcelData = new Object[rowCount][colCount];
//        for (int rCnt=1; rCnt<=rowCount;rCnt++){
//            for (int cCnt=0; cCnt<colCount;cCnt++){
//            	ExcelData[rCnt-1][cCnt] = getCellData(SheetName, rCnt, cCnt);
//            }
//        }
//        return ExcelData;
//   }
    
	@BeforeTest
	public void ConfigurationSetup(){
	try {
	fileInput = new FileInputStream(file);
	} catch (FileNotFoundException e) {
	e.printStackTrace();
	}
	prop = new Properties();
	try {
	prop.load(fileInput);
	} catch (IOException e) {
	e.printStackTrace();
	}
	}

	@BeforeTest
	public void startReport() {
		extent = new ExtentReports(System.getProperty("user.dir") + "/test-output/AvayaProfilerManager_ExtentReport.html", true);
		extent.addSystemInfo("Host Name", "ProfilerAutomation").addSystemInfo("Environment", "Regression Test")
				.addSystemInfo("User Name", "Shubham Patel");
		extent.loadConfig(new File(System.getProperty("user.dir") + "\\config\\extent-config.xml"));
	}
	
	@BeforeMethod
	public void HomePageNavigation() throws Throwable {
		DOMConfigurator.configure("log4j.xml");
		Thread.sleep(1000);

		ConfigurationSetup();
		driver = BrowserSetup.StartBrowser(prop.getProperty("Browsername"), prop.getProperty("Url"));
		log.info("Application launched");
		
		logger = extent.startTest("Login Page", "Login Page functionality testing");
		Assert.assertTrue(true);
		loginpage = new LoginPage(driver);
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		util = new utility(driver);
	
		loginpage.setUserName(prop.getProperty("UserId1"));
		log.info("username entered");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		loginpage.setPassword(prop.getProperty("Password1"));
		log.info("password entered");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		loginpage.getdomain(prop.getProperty("Domain1"));
		log.info("domain selected");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		loginpage.ClickOnLoginButton();
		log.info("login button clicked");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		util = new utility(driver);

	}

	@Test(dataProvider = "getCommonData", priority = 1, groups = { "TCID 01: Verifying Tspai Creation TestCase" }, enabled = true)
	
	public void Tsapicreation (String TSAPI_Name,String AES_Station_Link,String Priority) throws InterruptedException {
		DOMConfigurator.configure("log4j.xml");
		logger = extent.startTest("Tsapi Page", "Tsapi Page functionality testing");
		Assert.assertTrue(true);
		tsapipage = new TsapiPage(driver);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		util = new utility(driver);
		Thread.sleep(3000);
		tsapipage.ClickOnSystem_management();
		log.info("ClickOnSystem_management clicked");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		tsapipage.ClickOnTsapi_details();
		log.info("ClickOnTsapi_details clicked");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		tsapipage.ClickOnAdd_Tsapi_btn();
		log.info("ClickOnAdd_Tsapi_btn clicked");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		tsapipage.setTsapi_name(TSAPI_Name);
		log.info("Tsapi_name entered");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
//		tsapipage.getAES_Station_link(AES_Station_Link);
//		log.info("AES_Station_link selected");
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//
//		tsapipage.setPriority(Priority);
//		log.info("Tsapi_priority entered");
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//		
//		tsapipage.ClickOnAdd_btn_AES();
//		log.info("Add_btn_AES clicked");
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//		
//		tsapipage.ClickOnSave_btn_AES();
//		log.info("Save_btn_AES clicked");
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	
	}

	@Test(dataProvider = "getCommonData", priority = 2, groups = { "TCID 02: Verifying Tspai Deletion TestCase" }, enabled = true)
	
	public void Tsapideletion (String TSAPI_Name,String AES_Station_Link,String Priority) throws InterruptedException {
		DOMConfigurator.configure("log4j.xml");
		logger = extent.startTest("Tsapi Page", "Tsapi Page functionality testing");
		Assert.assertTrue(true);
		tsapipage = new TsapiPage(driver);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		util = new utility(driver);
		Thread.sleep(3000);
		tsapipage.ClickOnSystem_management();
		log.info("ClickOnSystem_management clicked");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		tsapipage.ClickOnTsapi_details();
		log.info("ClickOnTsapi_details clicked");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		tsapipage.ClickOnAdd_Tsapi_btn();
		log.info("ClickOnAdd_Tsapi_btn clicked");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		tsapipage.setTsapi_name(TSAPI_Name);
		log.info("Tsapi_name entered");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		tsapipage.getAES_Station_link(AES_Station_Link);
		log.info("AES_Station_link selected");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		tsapipage.setPriority(Priority);
		log.info("Tsapi_priority entered");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		tsapipage.ClickOnAdd_btn_AES();
		log.info("Add_btn_AES clicked");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		tsapipage.ClickOnSave_btn_AES();
		log.info("Save_btn_AES clicked");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	
	}
	
	

	@AfterMethod
	public void getResult(ITestResult result) throws Exception {
		if (result.getStatus() == ITestResult.SUCCESS) {
			logger.log(LogStatus.PASS, "Test Case Successfully executed is " + result.getName());
		} else if (result.getStatus() == ITestResult.FAILURE) {
			logger.log(LogStatus.FAIL, "Test Case failed is " + result.getName());
			logger.log(LogStatus.FAIL, "Test Case failed due to " + result.getThrowable());
			util = new utility(driver);
			String screenshotPath = util.getScreenshot(driver, result.getName());
			logger.log(LogStatus.FAIL, logger.addScreenCapture(screenshotPath));

		} else if (result.getStatus() == ITestResult.SKIP) {
			logger.log(LogStatus.SKIP, "Test Case Skipped is " + result.getName());
		}
		extent.flush();
		driver.close();
		recorder.stop();
	}

}